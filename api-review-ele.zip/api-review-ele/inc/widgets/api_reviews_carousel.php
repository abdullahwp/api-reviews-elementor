<?php
namespace api_reviews_Addon;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if (!defined('ABSPATH')) exit;
class api_reviews_carousel extends \Elementor\Widget_Base {

    public function __construct($data = [], $args = null) {
        parent::__construct($data, $args);

            wp_enqueue_style( 'slick-slider-css', plugins_url(). '/api-review-ele/inc/widget-assets/css/slick.min.css', array(), '1.0.0');
          
            wp_enqueue_style( 'style-main-css', plugins_url().'/api-review-ele/inc/widget-assets/css/style-main.css', array(), '1.0.0' );

            wp_register_script( 'slick-slider-js', site_url() . '/wp-content/plugins/api-review-ele/inc/widget-assets/js/slick.min.js', array('jquery'), '1.8.1', true );

            wp_register_script( 'custom-widget-js', site_url() . '/wp-content/plugins/api-review-ele/inc/widget-assets/js/custom-widget.js', array('jquery', 'slick-slider-js'), '1.0.0', true );

        
     }
    public function get_style_depends() {
        return ['style-main-css','slick-slider-css','slick-slider-theme-css'];
        }
 
    public function get_script_depends() {
        return ['slick-slider-js'];
        }
    public function get_name() {
		return 'api-review-carousel';
	}
	
	public function get_title() {
		return 'API Review Carousel';
	}
    protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'api-review-ele' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
    
        $this->add_control(
            'api_url',
            [
                'label' => __( 'API URL', 'api-review-ele' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'input_type' => 'url',
                'placeholder' => __( 'https://example.com/api', 'api-review-ele' ),
            ]
        );
        $this->add_control(
            'note_1',
            [
                'label' => __( 'Important Note', 'api-review-ele' ),
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => __( '<p>Ensure that the API URL is correct and returns the expected data format e.g JSON <br> <br> All keys supported Nested Keys e.g (information.name or use name) </p>', 'api-review-ele' ),
            ]
        );

            // Control for specifying the reviews key
        $this->add_control(
            'reviews_key',
            [
                'label' => __('Reviews Key', 'text-domain'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'reviews',
                'description' => __('Specify the key where the reviews are located in the API response.', 'text-domain'),
            ]
        );

    
        $this->add_control(
            'name_key',
            [
                'label' => __( 'Name Key', 'api-review-ele' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __( 'e.g. name', 'api-review-ele' ),
            ]
        );
    
        $this->add_control(
            'review_key',
            [
                'label' => __( 'Review Key', 'api-review-ele' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __( 'e.g. review', 'api-review-ele' ),
            ]
        );
    
        $this->add_control(
            'title_key',
            [
                'label' => __( 'Title Key', 'api-review-ele' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __( 'e.g. title', 'api-review-ele' ),
            ]
        );
    
        $this->add_control(
            'rating_key',
            [
                'label' => __( 'Rating Key', 'api-review-ele' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __( 'e.g. rating', 'api-review-ele' ),
            ]
        );
        $this->add_control(
            'limit',
            [
                'label' => __( 'Number of Reviews to Show', 'api-review-ele' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
                'min' => 1,
                'step' => 1,
            ]
        );
        $this->add_control(
            'columns',
            [
                'label' => __( 'Columns', 'api-review-ele' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 2,
                'min' => 1,
                'step' => 1,
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'style_section',
            [
                'label' => __( 'Style', 'api-review-ele' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
    
        // Box Styling
    $this->add_control(
        'box_background_color',
        [
            'label' => __( 'Box Background Color', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .review-item' => 'background-color: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'box_border_color',
        [
            'label' => __( 'Box Border Color', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .review-item' => 'border-color: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'box_border_radius',
        [
            'label' => __( 'Box Border Radius', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .review-item' => 'border-radius: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}};',
            ],
        ]
    );

    $this->add_control(
        'box_padding',
        [
            'label' => __( 'Box Padding', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .review-item' => 'padding: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}};',
            ],
        ]
    );

    // Title Styling
    $this->add_control(
        'title_color',
        [
            'label' => __( 'Title Color', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .review-item h3' => 'color: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'title_font_size',
        [
            'label' => __( 'Title Font Size', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'em', 'rem' ],
            'range' => [
                'px' => [
                    'min' => 10,
                    'max' => 100,
                    'step' => 1,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .review-item h3' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    );

    // Review Styling
    $this->add_control(
        'review_color',
        [
            'label' => __( 'Review Color', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .review-item p' => 'color: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'review_font_size',
        [
            'label' => __( 'Review Font Size', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'em', 'rem' ],
            'range' => [
                'px' => [
                    'min' => 10,
                    'max' => 100,
                    'step' => 1,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .review-item p' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    );

    // Name Styling
    $this->add_control(
        'name_color',
        [
            'label' => __( 'Name Color', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .review-item span' => 'color: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'name_font_size',
        [
            'label' => __( 'Name Font Size', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'em', 'rem' ],
            'range' => [
                'px' => [
                    'min' => 10,
                    'max' => 100,
                    'step' => 1,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .review-item span' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    );

    // Rating Styling
    $this->add_control(
        'rating_color',
        [
            'label' => __( 'Rating Color', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .star-rating' => 'color: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'rating_font_size',
        [
            'label' => __( 'Rating Font Size', 'api-review-ele' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'em', 'rem' ],
            'range' => [
                'px' => [
                    'min' => 10,
                    'max' => 100,
                    'step' => 1,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .star-rating span' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $this->add_control(
        'align', [
            'label' => __( 'Align', 'api-review-ele' ),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => esc_html__( 'Left', 'api-review-ele' ),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => esc_html__( 'Center', 'api-review-ele' ),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => esc_html__( 'Right', 'api-review-ele' ),
                    'icon' => 'eicon-text-align-right',
                ],
                'justify' => [
                    'title' => esc_html__( 'Justified', 'api-review-ele' ),
                    'icon' => 'eicon-text-align-justify',
                ],
            ],
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} ..review-item' => 'text-align: {{VALUE}};',
            ],
        ]
    );
    
        $this->end_controls_section();


    }

    private function get_nested_value($array, $key) {
        $keys = explode('.', $key);
        foreach ($keys as $k) {
            if (isset($array[$k])) {
                $array = $array[$k];
            } else {
                return null; // Key does not exist
            }
        }
        return $array;
    }

    protected function render() {
        $unique_id = $this->get_id();
        $allowed_tags = array(
            'span' => array(
                'class' => array(),
            ),
            'strong' => array(),
            'em' => array(),
        );
       
        $settings = $this->get_settings_for_display();
        $limit = $settings['limit'];
        $columns = $settings['columns'];
        // Fetch data from the API
        $response = wp_remote_get( $settings['api_url'] );
        if ( is_wp_error( $response ) ) {
            echo 'Failed to retrieve data from the API.';
            return;
        }
    
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        $reviews_key = $settings['reviews_key'];
        if ( ! $data ) {
            echo 'Invalid API response.';
            return;
        }
        echo '<div class="review-slider rts-' . esc_attr( $unique_id )  . '">';
        // Loop through the data and extract the necessary fields
        $count = 0; 
        foreach ( $data[$reviews_key] as $item ) {

            if ($count >= $limit) break;

            $name = $this->get_nested_value($item, $settings['name_key']);
            $review = $this->get_nested_value($item, $settings['review_key']);
            $title = $this->get_nested_value($item, $settings['title_key']);
            $rating = $this->get_nested_value($item, $settings['rating_key']);
            
            $rating_html = '';
            if ($rating) {
                $full_stars = floor($rating);
                $half_star = ($rating - $full_stars) >= 0.5 ? true : false;
                $empty_stars = 5 - $full_stars - ($half_star ? 1 : 0);
    
                // Full stars
                for ($i = 0; $i < $full_stars; $i++) {
                    $rating_html .= '<span class="star">&#9733;</span>'; // Full star
                }
    
                // Half star
                if ($half_star) {
                    $rating_html .= '<span class="star">&#189;</span>'; // Half star
                }
    
                // Empty stars
                for ($i = 0; $i < $empty_stars; $i++) {
                    $rating_html .= '<span class="star empty">&#9733;</span>'; // Empty star
                }
            }
           
            echo '<div class="review-item">';
            echo '<h3>' . esc_html( $title ) . '</h3>';
            echo '<p>' . esc_html( $review ) . '</p>';
            echo '<span>' . esc_html( $name ) . '</span>';
            echo '<div class="star-rating">' . wp_kses( $rating_html, $allowed_tags ) . '</div>';
            echo '</div>';

            $count++; 
        }
        echo '</div>';

?>
<script>
    jQuery(document).ready(function($) {
    $('.rts-<?php echo esc_attr( $unique_id ); ?>').slick({
        // Slick Slider options
        slidesToShow: <?php echo wp_kses( $columns, $allowed_tags );?>,
        slidesToScroll: 1,
        dots: false,
        arrows: true,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 5000,
        adaptiveHeight: true
        // Add more options as needed
    });
});

</script>


<?php

    }


  

}