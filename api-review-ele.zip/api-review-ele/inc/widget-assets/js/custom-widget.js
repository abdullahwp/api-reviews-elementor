jQuery(document).ready(function($) {
    $('.review-slider').slick({
        // Slick Slider options
        slidesToShow: 3,
        slidesToScroll: 1,
        dots: false,
        arrows: true,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 5000,
        // Add more options as needed
    });
});